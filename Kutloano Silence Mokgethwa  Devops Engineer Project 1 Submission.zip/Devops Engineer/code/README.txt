<Student Name : Kutloano Silence Mokgethwa>

Useful Links
static wesite link
	> http://my-892599007762-bucket.s3-website-us-east-1.amazonaws.com/
CloudFront distro link
	>d2n2okznes3fdl.cloudfront.net

Bucket Name 
	>my-892599007762-bucket

simple static website deployed on amazon web services(built using css and html)

here i deployed a site using,

Amazons storage services (s3)
	> S3 bucket is a public cloud storage resource available in Amazon Web Services' (AWS) Simple Storage Service (S3), an object storage offering. Amazon S3 buckets, which are similar to file folders, store objects, which consist of data and its descriptive metadata.

Identity Access Management (IAM)
	> provides fine-grained access control across all of AWS. With IAM, you can specify who can access which services and resources, and under which conditions. With IAM policies, you manage permissions to your workforce and systems to ensure least-privilege permissions.

Cloud Front
	>CloudFront is a content delivery network (CDN) service built for high performance, security, and developer convenience.
